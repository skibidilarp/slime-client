# Slime Client

Grüner Utility-Client für Fabric (Minecraft 1.21.11).

## Features
- ClickGUI (Rechts-Shift) mit frei wählbarer Akzentfarbe
- Slime-Chunk-Finder (Singleplayer automatisch, Server: /slimeseed <seed>)
- HUD: FPS und Koordinaten
- Speichert alle Einstellungen automatisch

## Voraussetzungen
Fabric Loader 0.18.1+, Fabric API, Java 21. Nur Client-Seite.
