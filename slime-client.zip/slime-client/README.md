# Slime Client (Fabric, Minecraft 1.21.11)

Voraussetzung: JDK 21 und IntelliJ IDEA (oder Gradle 9.x).

1. Ordner in IntelliJ öffnen, Gradle-Import abwarten.
2. Testen:   gradle runClient      (Gradle-Wrapper erzeugen: `gradle wrapper`)
3. Jar bauen: gradle build         -> build/libs/slimeclient-0.1.0.jar
4. Jar in den mods-Ordner legen (zusammen mit Fabric API 0.139.4+1.21.11).

Im Spiel: Rechts-Shift = Menü.  Server-Seed für den Slime-Finder: /slimeseed <zahl>
