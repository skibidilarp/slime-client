package de.slimeclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.server.integrated.IntegratedServer;
import java.util.Random;

public class SlimeFinder {
    // Java Edition, Overworld
    public static boolean isSlimeChunk(long seed, int cx, int cz) {
        Random rnd = new Random(seed
                + (int) (cx * cx * 4987142)
                + (int) (cx * 5947611)
                + (long) (cz * cz) * 4392871L
                + (long) (cz * 389711)
                ^ 987234911L);
        return rnd.nextInt(10) == 0;
    }

    private static Long seed(MinecraftClient mc) {
        IntegratedServer s = mc.getServer();                 // Singleplayer: Seed automatisch
        if (s != null) return s.getOverworld().getSeed();
        return SlimeConfig.I.seedSet ? SlimeConfig.I.seed : null; // Server: /slimeseed <seed>
    }

    public static void render(DrawContext ctx, MinecraftClient mc) {
        final int R = 8, CELL = 7, SIZE = (2 * R + 1) * CELL;
        int x0 = ctx.getScaledWindowWidth() - SIZE - 6, y0 = 6;
        ctx.fill(x0 - 2, y0 - 2, x0 + SIZE + 2, y0 + SIZE + 2, SlimeConfig.accent(0xFF));
        ctx.fill(x0, y0, x0 + SIZE, y0 + SIZE, 0xE0101510);

        Long seed = seed(mc);
        if (seed == null) {
            ctx.drawText(mc.textRenderer, "Seed: /slimeseed <zahl>", x0 + 4, y0 + 4, 0xFFFFFFFF, true);
            return;
        }
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        for (int dz = -R; dz <= R; dz++) for (int dx = -R; dx <= R; dx++) {
            int px = x0 + (dx + R) * CELL, py = y0 + (dz + R) * CELL;
            boolean slime = isSlimeChunk(seed, pcx + dx, pcz + dz);
            ctx.fill(px + 1, py + 1, px + CELL, py + CELL, slime ? SlimeConfig.accent(0xD0) : 0x40FFFFFF);
        }
        int c = x0 + R * CELL, d = y0 + R * CELL;
        ctx.fill(c + 2, d + 2, c + CELL - 1, d + CELL - 1, 0xFFFFFFFF); // Spieler
    }
}
