package de.slimeclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

public class SlimeConfig {
    public static SlimeConfig I = new SlimeConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public int accent = 0x39D353;           // Akzentfarbe (RGB), frei änderbar im ClickGUI
    public long seed = 0;
    public boolean seedSet = false;
    public Map<String, Boolean> modules = new HashMap<>();

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("slimeclient.json"); }

    public static void load() {
        try { if (Files.exists(path())) I = GSON.fromJson(Files.readString(path()), SlimeConfig.class); }
        catch (Exception e) { I = new SlimeConfig(); }
        if (I == null) I = new SlimeConfig();
    }

    public static void save() {
        try { Files.writeString(path(), GSON.toJson(I)); } catch (Exception ignored) {}
    }

    public static int argb(int rgb, int alpha) { return (alpha << 24) | (rgb & 0xFFFFFF); }
    public static int accent(int alpha) { return argb(I.accent, alpha); }
}
