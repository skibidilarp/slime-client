package de.slimeclient;

import java.util.*;

public class ModuleManager {
    public enum Category { HUD, VISUALS }

    public static class Module {
        public final String name, desc;
        public final Category cat;
        public boolean enabled;
        Module(String n, String d, Category c) { name = n; desc = d; cat = c; }
        public void toggle() { enabled = !enabled; SlimeConfig.I.modules.put(name, enabled); SlimeConfig.save(); }
    }

    public static final List<Module> ALL = new ArrayList<>();
    static {
        ALL.add(new Module("FPS", "Zeigt die FPS", Category.HUD));
        ALL.add(new Module("Coordinates", "Zeigt deine Koordinaten", Category.HUD));
        ALL.add(new Module("Slime Finder", "Slime-Chunk-Karte (braucht Seed)", Category.VISUALS));
    }

    public static void init() {
        for (Module m : ALL) m.enabled = SlimeConfig.I.modules.getOrDefault(m.name, false);
    }

    public static boolean on(String name) {
        for (Module m : ALL) if (m.name.equals(name)) return m.enabled;
        return false;
    }
}
