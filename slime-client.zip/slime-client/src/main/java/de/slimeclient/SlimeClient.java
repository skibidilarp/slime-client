package de.slimeclient;

import com.mojang.brigadier.arguments.LongArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class SlimeClient implements ClientModInitializer {
    public static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        SlimeConfig.load();
        ModuleManager.init();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.slimeclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("slimeclient", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) mc.setScreen(new ClickGuiScreen());
        });

        HudRenderCallback.EVENT.register(SlimeClient::renderHud);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) ->
            dispatcher.register(ClientCommandManager.literal("slimeseed")
                .then(ClientCommandManager.argument("seed", LongArgumentType.longArg())
                    .executes(ctx -> {
                        SlimeConfig.I.seed = LongArgumentType.getLong(ctx, "seed");
                        SlimeConfig.I.seedSet = true;
                        SlimeConfig.save();
                        ctx.getSource().sendFeedback(Text.literal("Slime-Seed gespeichert."));
                        return 1;
                    }))));
    }

    private static void renderHud(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        int y = 6, col = SlimeConfig.accent(0xFF);
        if (ModuleManager.on("FPS")) {
            ctx.drawText(mc.textRenderer, mc.getCurrentFps() + " FPS", 6, y, col, true); y += 11;
        }
        if (ModuleManager.on("Coordinates")) {
            ctx.drawText(mc.textRenderer, "XYZ " + mc.player.getBlockX() + " " + mc.player.getBlockY()
                    + " " + mc.player.getBlockZ(), 6, y, col, true);
        }
        if (ModuleManager.on("Slime Finder")) SlimeFinder.render(ctx, mc);
    }
}
