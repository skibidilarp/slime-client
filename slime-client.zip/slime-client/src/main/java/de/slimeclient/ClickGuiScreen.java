package de.slimeclient;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.awt.Color;

public class ClickGuiScreen extends Screen {
    private static final int W = 320, H = 220;
    private static final int[] PRESETS = {0x39D353, 0x00E5FF, 0xA855F7, 0xFF4FA3, 0xFF9F1C, 0xFF3B3B, 0xFFFFFF};
    private ModuleManager.Category tab = ModuleManager.Category.HUD;

    public ClickGuiScreen() { super(Text.literal("Slime Client")); }

    private int x() { return (width - W) / 2; }
    private int y() { return (height - H) / 2; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x = x(), y = y();
        ctx.fill(x, y, x + W, y + H, 0xF0101510);
        ctx.fill(x, y, x + W, y + 22, SlimeConfig.accent(0xFF));
        ctx.drawText(textRenderer, "SLIME CLIENT", x + 8, y + 7, 0xFF000000, false);

        // Kategorien
        int ty = y + 30;
        for (ModuleManager.Category c : ModuleManager.Category.values()) {
            boolean sel = c == tab;
            ctx.fill(x + 6, ty, x + 86, ty + 18, sel ? SlimeConfig.accent(0x90) : 0x30FFFFFF);
            ctx.drawText(textRenderer, c.name(), x + 12, ty + 5, 0xFFFFFFFF, true);
            ty += 22;
        }

        // Module
        int my0 = y + 30;
        for (ModuleManager.Module m : ModuleManager.ALL) {
            if (m.cat != tab) continue;
            ctx.fill(x + 94, my0, x + W - 6, my0 + 26, m.enabled ? SlimeConfig.accent(0x70) : 0x30FFFFFF);
            ctx.drawText(textRenderer, m.name, x + 100, my0 + 4, 0xFFFFFFFF, true);
            ctx.drawText(textRenderer, m.desc, x + 100, my0 + 15, 0xFFAAAAAA, false);
            ctx.drawText(textRenderer, m.enabled ? "AN" : "AUS", x + W - 30, my0 + 9,
                    m.enabled ? 0xFFFFFFFF : 0xFF888888, true);
            my0 += 30;
        }

        // Farbwahl
        int cy = y + H - 50;
        ctx.drawText(textRenderer, "Akzentfarbe", x + 8, cy - 2, 0xFFFFFFFF, true);
        for (int i = 0; i < PRESETS.length; i++)
            ctx.fill(x + 8 + i * 18, cy + 10, x + 22 + i * 18, cy + 24, 0xFF000000 | PRESETS[i]);
        for (int i = 0; i < W - 16; i++) { // Farbleiste: klicken = Farbton wählen
            int rgb = Color.HSBtoRGB(i / (float) (W - 16), 0.8f, 0.9f);
            ctx.fill(x + 8 + i, cy + 30, x + 9 + i, cy + 42, 0xFF000000 | (rgb & 0xFFFFFF));
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int x = x(), y = y();

        int ty = y + 30;
        for (ModuleManager.Category c : ModuleManager.Category.values()) {
            if (in(mx, my, x + 6, ty, 80, 18)) { tab = c; return true; }
            ty += 22;
        }
        int my0 = y + 30;
        for (ModuleManager.Module m : ModuleManager.ALL) {
            if (m.cat != tab) continue;
            if (in(mx, my, x + 94, my0, W - 100, 26)) { m.toggle(); return true; }
            my0 += 30;
        }
        int cy = y + H - 50;
        for (int i = 0; i < PRESETS.length; i++)
            if (in(mx, my, x + 8 + i * 18, cy + 10, 14, 14)) { setAccent(PRESETS[i]); return true; }
        if (in(mx, my, x + 8, cy + 30, W - 16, 12)) {
            float hue = (float) ((mx - (x + 8)) / (W - 16));
            setAccent(Color.HSBtoRGB(hue, 0.8f, 0.9f) & 0xFFFFFF);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void setAccent(int rgb) { SlimeConfig.I.accent = rgb; SlimeConfig.save(); }
}
